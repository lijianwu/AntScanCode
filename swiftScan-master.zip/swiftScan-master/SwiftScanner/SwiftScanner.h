//
//  SwiftScanner.h
//  SwiftScanner
//
//  Created by 杨西川 on 16/09/2017.
//  Copyright © 2017 xialibing. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftScanner.
FOUNDATION_EXPORT double SwiftScannerVersionNumber;

//! Project version string for SwiftScanner.
FOUNDATION_EXPORT const unsigned char SwiftScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftScanner/PublicHeader.h>


