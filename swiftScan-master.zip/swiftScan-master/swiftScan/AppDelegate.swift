//
//  AppDelegate.swift
//  swiftScan
//
//  Created by xialibing on 15/11/25.
//  Copyright © 2015年 xialibing. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    internal func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {

//        window? = UIWindow()
//        window?.frame = UIScreen.main.bounds;
//        
//        window?.rootViewController =  UINavigationController(rootViewController: MainTableViewController())
//        
//        window?.makeKeyAndVisible();
        return true
    }
}
